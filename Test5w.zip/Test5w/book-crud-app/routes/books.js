const express = require('express');
const router = express.Router();
const { Book } = require('../models');

// List all books
router.get('/', async (req, res) => {
  const books = await Book.findAll();
  res.render('index', { books });
});

// Display form to create a new book
router.get('/new', (req, res) => {
  res.render('new');
});

// Handle form submission to create a new book
router.post('/', async (req, res) => {
  const { title, author, year } = req.body;
  await Book.create({ title, author, year });
  res.redirect('/books');
});

// Delete a book
router.post('/:id/delete', async (req, res) => {
  await Book.destroy({ where: { id: req.params.id } });
  res.redirect('/books');
});

module.exports = router;
