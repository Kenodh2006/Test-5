require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const port = 3000;

app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({ extended: true }));

// Root route redirect to /books
app.get('/', (req, res) => {
  res.redirect('/books');
});

const bookRoutes = require('./routes/books');
app.use('/books', bookRoutes);

app.listen(port, () => {
  console.log(`App running on http://localhost:${port}`);
});
